﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace 과제4
{

    public partial class Form2 : Form
    {
        ListViewItem item;
        Form1 f1;

        public Form2()
        {
            InitializeComponent();
        }
        public Form2(Form1 f)
        {
            InitializeComponent();
            f1 = f;
            dateTimePicker1.MinDate = DateTime.Today;
        }
        public string SetToDo
        {
            set { textBox_t.Text = value; }
        }
        public ListViewItem SetItem
        {
            set { item = value; }
        }
        public string SetDate
        {
            set { dateTimePicker1.Value = DateTime.Parse(value); }
        }
        public string SetSelect
        {
            set
            {
                if (value == "높음")
                    high.Checked = true;
                else if (value == "중간")
                    middle.Checked = true;
                else if (value == "낮음")
                    low.Checked = true;
            }
        }
        private void add_button_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox_t.Text))
            {
                MessageBox.Show("할 일을 입력해 주세요!", "알림");
                textBox_t.Focus();
                return;
            }
            if (dateTimePicker1.Value.Date < DateTime.Today)
            {
                MessageBox.Show("기한은 오늘보다 이전일 수 없습니다.", "날짜 오류");
                return;
            }

            if (!high.Checked && !middle.Checked && !low.Checked)
            {
                MessageBox.Show("우선순위를 선택해 주세요!", "알림");
                return;
            }
            string todo = textBox_t.Text;
            string dueDate = dateTimePicker1.Value.ToString("yyyy-MM-dd");
            string p = "";
            if (high.Checked)
            {
                p = "높음";
            }
            else if (middle.Checked)
            {
                p = "중간";
            }
            else if (low.Checked)
            {
                p = "낮음";
            }
            f1.AddToListView(todo, dueDate, p);
            clearItems();
        }
        private void clearItems()
        {
            textBox_t.Clear();
            dateTimePicker1.Value = DateTime.Now;
            high.Checked = false;
            middle.Checked = false;
            low.Checked = false;
            textBox_t.Focus();
        }

        private void edit_button_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox_t.Text))
            {
                MessageBox.Show("할 일을 입력해 주세요!", "알림");
                textBox_t.Focus();
                return;
            }
            if (dateTimePicker1.Value.Date < DateTime.Today)
            {
                MessageBox.Show("기한은 오늘보다 이전일 수 없습니다.", "날짜 오류");
                return;
            }
            item.SubItems[1].Text = textBox_t.Text;
            item.SubItems[2].Text = dateTimePicker1.Value.ToString("yyyy-MM-dd");
            if (high.Checked)
            {
                item.SubItems[3].Text = "높음";
            }
            else if (middle.Checked)
            {
                item.SubItems[3].Text = "중간";
            }
            else if (low.Checked)
            {
                item.SubItems[3].Text = "낮음";
            }

            item = null;
            textBox_t.Clear();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }
    }
}
