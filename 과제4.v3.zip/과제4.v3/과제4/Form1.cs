using Microsoft.VisualBasic.Devices;

namespace 과제4
{
    public partial class Form1 : Form
    {
        Form2 f2;

        public Form1()
        {
            InitializeComponent();
            textBox_today.Text = DateTime.Now.ToString("yyyy-MM-dd");
            ListViewItem item = new ListViewItem("");
            item.SubItems.Add("C# 리스트뷰 과제");
            item.SubItems.Add("2026-05-06");
            item.SubItems.Add("높음");
            item.SubItems.Add(DateTime.Now.ToString("yyyy-MM-dd"));
            listView1.Items.Add(item); //예시용
        }

        public void AddToListView(string todo, string dueDate, string priority)
        {
            ListViewItem item = new ListViewItem("");
            item.SubItems.Add(todo);
            item.SubItems.Add(dueDate);
            item.SubItems.Add(priority);
            item.SubItems.Add(DateTime.Now.ToString("yyyy-MM-dd"));
            listView1.Items.Add(item);
        }
        private void edit_dialog_Click(object sender, EventArgs e)
        {
            f2 = new Form2(this);
            f2.Show();
        }

        private void search_button_Click(object sender, EventArgs e)
        {
            string s = textBox_search.Text.Trim();
            if (string.IsNullOrWhiteSpace(s))
            {
                MessageBox.Show("검색어를 입력해주세요.");
                return;
            }
            bool find = false;
            foreach (ListViewItem item in listView1.Items)
            {
                if (item.SubItems[1].Text.Contains(s))
                {
                    item.BackColor = Color.Yellow;
                    item.EnsureVisible(); //항목 위치로 스크롤되게 
                    find = true;
                }
                else
                {
                    item.BackColor = Color.White;
                }
            }
            if (!find)
            {
                MessageBox.Show($"{s} 가 포함된 항목이 없습니다.");
            }
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count > 0)
            {
                ListViewItem item = listView1.SelectedItems[0];
                string secondColumn = item.SubItems[1].Text;     // 할 일
                string thirdColumn = item.SubItems[2].Text;     // 날짜
                string forthColumn = item.SubItems[3].Text;     // 우선순위
                if (f2 != null) {
                    f2.SetToDo=secondColumn;
                    f2.SetDate = thirdColumn;
                    f2.SetSelect = forthColumn;
                    f2.SetItem=item;
                }

            }
        }
    
    }
}
