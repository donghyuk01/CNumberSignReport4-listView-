﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace 과제4
{
    public partial class Form3 : Form
    {
        ListViewItem item;
        Form1 f1;
        public Form3()
        {
            InitializeComponent();
        }
        public Form3(Form1 form1)
        {
            f1 = form1;
            InitializeComponent();
            dateTimePicker1.MinDate = DateTime.Today;
        }
        public string SetToDo
        {
            set { textBox1.Text = value; }
        }
        public ListViewItem SetItem
        {
            set { item = value; }
        }
        public string SetDate
        {
            set { dateTimePicker1.Value = DateTime.Parse(value); }
        }
        public string SetSelect
        {
            set {
                if (value == "높음")
                    high.Checked=true;
                else if (value == "중간")
                    middle.Checked = true;
                else if (value == "낮음")
                    low.Checked = true;
            }   
        }
        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox1.Text))
            {
                MessageBox.Show("할 일을 입력해 주세요!", "알림");
                textBox1.Focus();
                return;
            }
            if (dateTimePicker1.Value.Date < DateTime.Today)
            {
                MessageBox.Show("기한은 오늘보다 이전일 수 없습니다.", "날짜 오류");
                return;
            }
            item.SubItems[1].Text=textBox1.Text;
            item.SubItems[2].Text= dateTimePicker1.Value.ToString("yyyy-MM-dd");
            if (high.Checked)
            {
                item.SubItems[3].Text = "높음";
            }
            else if (middle.Checked)
            {
                item.SubItems[3].Text = "중간";
            }
            else if (low.Checked)
            {
                item.SubItems[3].Text = "낮음";
            }

            item = null;
            textBox1.Text = "";
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            item = null;
            textBox1.Text = "";
            this.Close();
        }
    }
}
