﻿namespace 과제4
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            textBox1 = new TextBox();
            button1 = new Button();
            button2 = new Button();
            high = new RadioButton();
            middle = new RadioButton();
            low = new RadioButton();
            dateTimePicker1 = new DateTimePicker();
            SuspendLayout();
            // 
            // textBox1
            // 
            textBox1.Font = new Font("맑은 고딕", 12F, FontStyle.Regular, GraphicsUnit.Point, 129);
            textBox1.Location = new Point(107, 88);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(485, 50);
            textBox1.TabIndex = 0;
            // 
            // button1
            // 
            button1.Location = new Point(24, 385);
            button1.Name = "button1";
            button1.Size = new Size(231, 91);
            button1.TabIndex = 1;
            button1.Text = "수정하기";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(451, 385);
            button2.Name = "button2";
            button2.Size = new Size(231, 91);
            button2.TabIndex = 2;
            button2.Text = "취소";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // high
            // 
            high.AutoSize = true;
            high.Location = new Point(57, 177);
            high.Margin = new Padding(6);
            high.Name = "high";
            high.Size = new Size(93, 36);
            high.TabIndex = 4;
            high.TabStop = true;
            high.Text = "높음";
            high.UseVisualStyleBackColor = true;
            // 
            // middle
            // 
            middle.AutoSize = true;
            middle.Location = new Point(316, 177);
            middle.Margin = new Padding(6);
            middle.Name = "middle";
            middle.Size = new Size(93, 36);
            middle.TabIndex = 5;
            middle.TabStop = true;
            middle.Text = "중간";
            middle.UseVisualStyleBackColor = true;
            // 
            // low
            // 
            low.AutoSize = true;
            low.Location = new Point(564, 177);
            low.Margin = new Padding(6);
            low.Name = "low";
            low.Size = new Size(93, 36);
            low.TabIndex = 6;
            low.TabStop = true;
            low.Text = "낮음";
            low.UseVisualStyleBackColor = true;
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(204, 271);
            dateTimePicker1.Margin = new Padding(6);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(316, 39);
            dateTimePicker1.TabIndex = 7;
            // 
            // Form3
            // 
            AutoScaleDimensions = new SizeF(14F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(720, 581);
            Controls.Add(dateTimePicker1);
            Controls.Add(low);
            Controls.Add(middle);
            Controls.Add(high);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(textBox1);
            Name = "Form3";
            Text = "Form3";
            Load += Form3_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textBox1;
        private Button button1;
        private Button button2;
        private RadioButton high;
        private RadioButton middle;
        private RadioButton low;
        private DateTimePicker dateTimePicker1;
    }
}