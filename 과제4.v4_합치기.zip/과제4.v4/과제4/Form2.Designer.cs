﻿namespace 과제4
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            button1 = new Button();
            low = new RadioButton();
            middle = new RadioButton();
            high = new RadioButton();
            dateTimePicker1 = new DateTimePicker();
            add_button = new Button();
            textBox_t = new MaskedTextBox();
            del_button = new Button();
            edit_button = new Button();
            save_button = new Button();
            load_button = new Button();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.Controls.Add(button1);
            panel1.Controls.Add(low);
            panel1.Controls.Add(middle);
            panel1.Controls.Add(high);
            panel1.Controls.Add(dateTimePicker1);
            panel1.Controls.Add(add_button);
            panel1.Controls.Add(textBox_t);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Margin = new Padding(4, 5, 4, 5);
            panel1.Name = "panel1";
            panel1.Size = new Size(741, 242);
            panel1.TabIndex = 0;
            // 
            // button1
            // 
            button1.Location = new Point(643, 198);
            button1.Margin = new Padding(4, 5, 4, 5);
            button1.Name = "button1";
            button1.Size = new Size(81, 38);
            button1.TabIndex = 4;
            button1.Text = "초기화";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // low
            // 
            low.AutoSize = true;
            low.Location = new Point(317, 143);
            low.Margin = new Padding(4, 5, 4, 5);
            low.Name = "low";
            low.Size = new Size(73, 29);
            low.TabIndex = 3;
            low.TabStop = true;
            low.Text = "낮음";
            low.UseVisualStyleBackColor = true;
            // 
            // middle
            // 
            middle.AutoSize = true;
            middle.Location = new Point(173, 143);
            middle.Margin = new Padding(4, 5, 4, 5);
            middle.Name = "middle";
            middle.Size = new Size(73, 29);
            middle.TabIndex = 3;
            middle.TabStop = true;
            middle.Text = "중간";
            middle.UseVisualStyleBackColor = true;
            // 
            // high
            // 
            high.AutoSize = true;
            high.Location = new Point(29, 143);
            high.Margin = new Padding(4, 5, 4, 5);
            high.Name = "high";
            high.Size = new Size(73, 29);
            high.TabIndex = 3;
            high.TabStop = true;
            high.Text = "높음";
            high.UseVisualStyleBackColor = true;
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(497, 68);
            dateTimePicker1.Margin = new Padding(4, 5, 4, 5);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(227, 31);
            dateTimePicker1.TabIndex = 2;
            // 
            // add_button
            // 
            add_button.Location = new Point(497, 127);
            add_button.Margin = new Padding(4, 5, 4, 5);
            add_button.Name = "add_button";
            add_button.Size = new Size(229, 65);
            add_button.TabIndex = 1;
            add_button.Text = "추가";
            add_button.UseVisualStyleBackColor = true;
            add_button.Click += add_button_Click;
            // 
            // textBox_t
            // 
            textBox_t.Font = new Font("맑은 고딕", 12F, FontStyle.Regular, GraphicsUnit.Point, 129);
            textBox_t.Location = new Point(20, 58);
            textBox_t.Margin = new Padding(4, 5, 4, 5);
            textBox_t.Name = "textBox_t";
            textBox_t.Size = new Size(431, 39);
            textBox_t.TabIndex = 0;
            // 
            // del_button
            // 
            del_button.Location = new Point(29, 252);
            del_button.Margin = new Padding(4, 5, 4, 5);
            del_button.Name = "del_button";
            del_button.Size = new Size(129, 72);
            del_button.TabIndex = 1;
            del_button.Text = "삭제";
            del_button.UseVisualStyleBackColor = true;
            del_button.Click += del_button_Click;
            // 
            // edit_button
            // 
            edit_button.Location = new Point(173, 252);
            edit_button.Margin = new Padding(4, 5, 4, 5);
            edit_button.Name = "edit_button";
            edit_button.Size = new Size(129, 72);
            edit_button.TabIndex = 1;
            edit_button.Text = "편집";
            edit_button.UseVisualStyleBackColor = true;
            edit_button.Click += edit_button_Click;
            // 
            // save_button
            // 
            save_button.Location = new Point(513, 252);
            save_button.Margin = new Padding(4, 5, 4, 5);
            save_button.Name = "save_button";
            save_button.Size = new Size(86, 72);
            save_button.TabIndex = 1;
            save_button.Text = "저장";
            save_button.UseVisualStyleBackColor = true;
            save_button.Click += save_button_Click;
            // 
            // load_button
            // 
            load_button.Location = new Point(607, 252);
            load_button.Margin = new Padding(4, 5, 4, 5);
            load_button.Name = "load_button";
            load_button.Size = new Size(96, 72);
            load_button.TabIndex = 1;
            load_button.Text = "불러오기";
            load_button.UseVisualStyleBackColor = true;
            load_button.Click += load_button_Click;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(741, 358);
            Controls.Add(load_button);
            Controls.Add(save_button);
            Controls.Add(edit_button);
            Controls.Add(del_button);
            Controls.Add(panel1);
            Margin = new Padding(4, 5, 4, 5);
            Name = "Form2";
            Text = "Form2";
            Load += Form2_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private RadioButton middle;
        private RadioButton high;
        private DateTimePicker dateTimePicker1;
        private Button add_button;
        private MaskedTextBox textBox_t;
        private RadioButton low;
        private Button del_button;
        private Button edit_button;
        private Button save_button;
        private Button load_button;
        private Button button1;
    }
}