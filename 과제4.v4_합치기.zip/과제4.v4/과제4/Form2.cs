﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace 과제4
{

    public partial class Form2 : Form
    {
        ListViewItem item;
        Form1 f1;

        public Form2() 
        {
            InitializeComponent();
        }
        public Form2(Form1 f)
        {
            InitializeComponent();
            f1 = f;
            dateTimePicker1.MinDate = DateTime.Today;
        }
        public string SetToDo
        {
            set { textBox_t.Text = value; }
        }
        public ListViewItem SetItem
        {
            set { item = value; }
        }
        public string SetDate
        {
            set { dateTimePicker1.Value = DateTime.Parse(value); }
        }
        public string SetSelect
        {
            set
            {
                if (value == "높음")
                    high.Checked = true;
                else if (value == "중간")
                    middle.Checked = true;
                else if (value == "낮음")
                    low.Checked = true;
            }
        }
        private bool input_date()
        {
            if (string.IsNullOrWhiteSpace(textBox_t.Text))
            {
                MessageBox.Show("할 일을 입력해 주세요!", "알림");
                textBox_t.Focus();
                return false;
            }

            if (!high.Checked && !middle.Checked && !low.Checked)
            {
                MessageBox.Show("우선순위를 선택해 주세요!", "알림");
                return false;
            }
            return true;
        }
        private void add_button_Click(object sender, EventArgs e)
        {
            if (!input_date())
            {
                return;
            }
            string todo = textBox_t.Text;
            string dueDate = dateTimePicker1.Value.ToString("yyyy-MM-dd");
            string p = "";
            if (high.Checked)
            {
                p = "높음";
            }
            else if (middle.Checked)
            {
                p = "중간";
            }
            else if (low.Checked)
            {
                p = "낮음";
            }
            f1.AddToListView(todo, dueDate, p);
            clearItems();
        }
        private void clearItems()
        {
            textBox_t.Clear();
            dateTimePicker1.Value = DateTime.Now;
            high.Checked = false;
            middle.Checked = false;
            low.Checked = false;
            textBox_t.Focus();
        }

        private void edit_button_Click(object sender, EventArgs e)
        {
            if (!input_date())
            {
                return;
            }
            item.SubItems[1].Text = textBox_t.Text;
            item.SubItems[2].Text = dateTimePicker1.Value.ToString("yyyy-MM-dd");
            if (high.Checked)
            {
                item.SubItems[3].Text = "높음";
            }
            else if (middle.Checked)
            {
                item.SubItems[3].Text = "중간";
            }
            else if (low.Checked)
            {
                item.SubItems[3].Text = "낮음";
            }

            item = null;
            clearItems();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            clearItems();
        }

        private void del_button_Click(object sender, EventArgs e)
        {

            if (item == null)
            {
                MessageBox.Show("삭제할 항목을 선택해주세요.", "알림");
                return;
            }
            DialogResult result = MessageBox.Show("삭제하시겠습니까? ", "삭제 확인", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes) { }
            {
                f1.deleteItems();
                clearItems();
            }
        }

        private void save_button_Click(object sender, EventArgs e)
        {
          
            SaveFileDialog sfd = new SaveFileDialog(); // 저장 창 생성
            sfd.Filter = "텍스트 파일 (*.txt)|*.txt";
            sfd.FileName = "체크리스트.txt";

            if (sfd.ShowDialog() == DialogResult.OK) // 존재여부
            {
                try
                {
                    using (StreamWriter sw = new StreamWriter(sfd.FileName))
                    {
                        foreach (ListViewItem item in f1.listView1.Items)
                        {                
                            string line = string.Format("{0}|{1}|{2}|{3}|{4}",
                                item.Text,                  // 상태
                                item.SubItems[1].Text,     // 할 일
                                item.SubItems[2].Text,     // 기한
                                item.SubItems[3].Text,     // 우선순위
                                item.SubItems[4].Text      // 추가 날짜
                            );
                            sw.WriteLine(line);
                        }
                    }
                    MessageBox.Show("성공적으로 저장되었습니다!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("에러 발생: " + ex.Message);
                }
            }
        }

        private void load_button_Click(object sender, EventArgs e)
        {
            bool checkError = false;
            OpenFileDialog ofd = new OpenFileDialog(); // 불러오는 창 생성
            ofd.Filter = "텍스트 파일 (*.txt)|*.txt";
            ofd.Title = "체크리스트 불러오기";

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    string[] lines = File.ReadAllLines(ofd.FileName, Encoding.UTF8);
                    foreach (ListViewItem item in f1.listView1.Items)
                    {
                        f1.listView1.Items.Remove(item);
                    }

                    foreach (string line in lines)
                    {
                        // 저장할 때 썼던 구분자 '|'로 자름
                        string[] data = line.Split('|');
                      
                            if (data.Length >= 5) // 손상방지 5개보다 작으면 그건 잘못된 데이터
                        {
                            ListViewItem newItem = new ListViewItem(data[0]); // 상태
                            newItem.SubItems.Add(data[1]); // 할 일
                            newItem.SubItems.Add(data[2]); // 기한
                            newItem.SubItems.Add(data[3]); // 우선순위
                            newItem.SubItems.Add(data[4]); // 추가 날짜

                            // Form1의 리스트뷰에 추가
                            f1.listView1.Items.Add(newItem);
                        }
                        else if (data.Length == 0) { }
                        else { 
                            checkError = true;
                        }
                    }
                    if (checkError)
                        MessageBox.Show("손상되었거나 잘못된 데이터가 있습니다.", "알림");
                    else
                        MessageBox.Show("데이터를 성공적으로 불러왔습니다!", "알림");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("불러오기 중 오류가 발생했습니다: " + ex.Message, "오류");
                }
            }
        }
    }
}
