using Microsoft.VisualBasic.Devices;
using System.Collections;

namespace 과제4
{
    public partial class Form1 : Form
    {
        Form2 f2;

        public Form1()
        {
            InitializeComponent();
            textBox_today.Text = DateTime.Now.ToString("yyyy-MM-dd");
            ListViewItem item = new ListViewItem("");
            item.SubItems.Add("C# 리스트뷰 과제");
            item.SubItems.Add("2026-05-06");
            item.SubItems.Add("높음");
            item.SubItems.Add(DateTime.Now.ToString("yyyy-MM-dd"));
            listView1.Items.Add(item); //예시용
        }

        public void AddToListView(string todo, string dueDate, string priority)
        {
            ListViewItem item = new ListViewItem("");
            item.SubItems.Add(todo);
            item.SubItems.Add(dueDate);
            item.SubItems.Add(priority);
            item.SubItems.Add(DateTime.Now.ToString("yyyy-MM-dd"));
            listView1.Items.Add(item);
        }
        private void edit_dialog_Click(object sender, EventArgs e)
        {
            f2 = new Form2(this);
            f2.Show();
        }

        private void search_button_Click(object sender, EventArgs e)
        {
            string s = textBox_search.Text.Trim();
            if (string.IsNullOrWhiteSpace(s))
            {
                MessageBox.Show("검색어를 입력해주세요.");
                return;
            }
            bool find = false;
            foreach (ListViewItem item in listView1.Items)
            {
                if (item.SubItems[1].Text.Contains(s))
                {
                    item.BackColor = Color.Yellow;
                    item.EnsureVisible(); //항목 위치로 스크롤되게 
                    //textBox_search.Clear();
                    find = true;
                }
                else
                {
                    item.BackColor = Color.White;
                }
            }
            if (!find)
            {
                MessageBox.Show($"{s} 가 포함된 항목이 없습니다.");
            }
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count > 0)
            {
                ListViewItem item = listView1.SelectedItems[0];
                string secondColumn = item.SubItems[1].Text;     // 할 일
                string thirdColumn = item.SubItems[2].Text;     // 날짜
                string forthColumn = item.SubItems[3].Text;     // 우선순위
                if (f2 != null)
                {
                    f2.SetToDo = secondColumn;
                    f2.SetDate = thirdColumn;
                    f2.SetSelect = forthColumn;
                    f2.SetItem = item;
                }

            }
        }
        public void deleteItems()
        {
            int c = listView1.SelectedItems.Count;
            if (c > 0)
            {
                for (int i = c - 1; i >= 0; i--)
                {
                    listView1.Items.Remove(listView1.SelectedItems[i]);
                }
            }
        }

        private int sortColumn = -1;
        private void listView1_ColumnClick(object sender, ColumnClickEventArgs e)
        {
            if (e.Column == sortColumn)
            {
                // 같은 열 클릭시 오름차순/내림차순 토글
                if (listView1.Sorting == SortOrder.Ascending)
                    listView1.Sorting = SortOrder.Descending;
                else
                    listView1.Sorting = SortOrder.Ascending;
            }
            else
            {
                // 다른 열 클릭시 오름차순으로 시작
                sortColumn = e.Column;
                listView1.Sorting = SortOrder.Ascending;
            }

            listView1.ListViewItemSorter = new ListViewItemComparer(sortColumn, listView1.Sorting);
            // 사용이유 ListViewItemSorter ListView의 정렬 방법 정의
            // 높음, 중간, 낮음이 기존 정렬로는 정렬이 안됨 낮음->높음->중간 순
            // 그래서 정렬 방법을 아이템 3번만 정의
            // IComparer 인터페이스로만 받을수 있어서 클래스 새롭게 정의함
            listView1.Sort();
        }
        public void updateCheck()
        {
            int total = listView1.Items.Count;
            int count = listView1.CheckedItems.Count;

            textBox_state.Text = $"완료된 할 일: {count} / {total}";
        }

        private void listView1_ItemChecked(object sender, ItemCheckedEventArgs e)
        {
            updateCheck();
        }

        private void textBox_search_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox_search.Text))
            {
                // 검색 창을 지웠을때 작동
                foreach (ListViewItem item in listView1.Items)
                {
                    item.BackColor = Color.White;
                }
            }
        }
    }
}
public class ListViewItemComparer : IComparer
{
    private int col;
    private SortOrder order;

    public ListViewItemComparer(int column, SortOrder order)
    {
        col = column;
        this.order = order;
    }

    public int Compare(object x, object y)
    {
        string textX = ((ListViewItem)x).SubItems[col].Text;
        string textY = ((ListViewItem)y).SubItems[col].Text;

        int result;

        if (col == 3)  // 우선순위 열 커스텀 정렬
        {
            string[] order_list = { "높음", "중간", "낮음" };
            int indexX = Array.IndexOf(order_list, textX);
            int indexY = Array.IndexOf(order_list, textY);
            result = indexX.CompareTo(indexY);
        }
        else
        {
            result = String.Compare(textX, textY);
        }

        return order == SortOrder.Ascending ? result : -result;
    }

}