﻿namespace 과제4
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            listView1 = new ListView();
            columnHeader1 = new ColumnHeader();
            columnHeader2 = new ColumnHeader();
            columnHeader3 = new ColumnHeader();
            columnHeader4 = new ColumnHeader();
            columnHeader5 = new ColumnHeader();
            panel1 = new Panel();
            label2 = new Label();
            panel2 = new Panel();
            edit_dialog = new Button();
            label3 = new Label();
            label1 = new Label();
            textBox_state = new TextBox();
            textBox_today = new TextBox();
            search_button = new Button();
            textBox_search = new TextBox();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // listView1
            // 
            listView1.CheckBoxes = true;
            listView1.Columns.AddRange(new ColumnHeader[] { columnHeader1, columnHeader2, columnHeader3, columnHeader4, columnHeader5 });
            listView1.Dock = DockStyle.Fill;
            listView1.FullRowSelect = true;
            listView1.GridLines = true;
            listView1.Location = new Point(0, 133);
            listView1.MultiSelect = false;
            listView1.Name = "listView1";
            listView1.Size = new Size(644, 628);
            listView1.TabIndex = 0;
            listView1.UseCompatibleStateImageBehavior = false;
            listView1.View = View.Details;
            // 
            // columnHeader1
            // 
            columnHeader1.Text = "상태";
            columnHeader1.Width = 40;
            // 
            // columnHeader2
            // 
            columnHeader2.Text = "할 일";
            columnHeader2.TextAlign = HorizontalAlignment.Center;
            columnHeader2.Width = 340;
            // 
            // columnHeader3
            // 
            columnHeader3.Text = "기한";
            columnHeader3.TextAlign = HorizontalAlignment.Center;
            columnHeader3.Width = 100;
            // 
            // columnHeader4
            // 
            columnHeader4.Text = "우선순위";
            columnHeader4.TextAlign = HorizontalAlignment.Center;
            // 
            // columnHeader5
            // 
            columnHeader5.Text = "추가 날짜";
            columnHeader5.TextAlign = HorizontalAlignment.Center;
            columnHeader5.Width = 100;
            // 
            // panel1
            // 
            panel1.Controls.Add(label2);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(644, 35);
            panel1.TabIndex = 1;
            // 
            // label2
            // 
            label2.Font = new Font("맑은 고딕", 12F, FontStyle.Regular, GraphicsUnit.Point, 129);
            label2.Location = new Point(289, 9);
            label2.Name = "label2";
            label2.Size = new Size(126, 18);
            label2.TabIndex = 0;
            label2.Text = "체크리스트";
            label2.TextAlign = ContentAlignment.TopCenter;
            // 
            // panel2
            // 
            panel2.Controls.Add(edit_dialog);
            panel2.Controls.Add(label3);
            panel2.Controls.Add(label1);
            panel2.Controls.Add(textBox_state);
            panel2.Controls.Add(textBox_today);
            panel2.Controls.Add(search_button);
            panel2.Controls.Add(textBox_search);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(0, 35);
            panel2.Name = "panel2";
            panel2.Size = new Size(644, 98);
            panel2.TabIndex = 2;
            // 
            // edit_dialog
            // 
            edit_dialog.Location = new Point(484, 6);
            edit_dialog.Name = "edit_dialog";
            edit_dialog.Size = new Size(69, 32);
            edit_dialog.TabIndex = 7;
            edit_dialog.Text = "추가/편집";
            edit_dialog.UseVisualStyleBackColor = true;
            edit_dialog.Click += edit_dialog_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(33, 6);
            label3.Name = "label3";
            label3.Size = new Size(59, 15);
            label3.TabIndex = 6;
            label3.Text = "오늘 날짜";
            // 
            // label1
            // 
            label1.Font = new Font("맑은 고딕", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 129);
            label1.Location = new Point(42, 54);
            label1.Name = "label1";
            label1.Size = new Size(29, 23);
            label1.TabIndex = 5;
            label1.Text = "⌕";
            // 
            // textBox_state
            // 
            textBox_state.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            textBox_state.Location = new Point(484, 53);
            textBox_state.Name = "textBox_state";
            textBox_state.ReadOnly = true;
            textBox_state.Size = new Size(121, 23);
            textBox_state.TabIndex = 2;
            textBox_state.TextAlign = HorizontalAlignment.Right;
            // 
            // textBox_today
            // 
            textBox_today.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            textBox_today.BackColor = SystemColors.MenuBar;
            textBox_today.Location = new Point(98, 3);
            textBox_today.Name = "textBox_today";
            textBox_today.ReadOnly = true;
            textBox_today.Size = new Size(108, 23);
            textBox_today.TabIndex = 3;
            // 
            // search_button
            // 
            search_button.Anchor = AnchorStyles.Bottom;
            search_button.Location = new Point(375, 54);
            search_button.Name = "search_button";
            search_button.Size = new Size(57, 29);
            search_button.TabIndex = 1;
            search_button.Text = "검색";
            search_button.UseVisualStyleBackColor = true;
            search_button.Click += search_button_Click;
            // 
            // textBox_search
            // 
            textBox_search.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            textBox_search.Font = new Font("맑은 고딕", 12F, FontStyle.Regular, GraphicsUnit.Point, 129);
            textBox_search.Location = new Point(68, 54);
            textBox_search.Name = "textBox_search";
            textBox_search.Size = new Size(279, 29);
            textBox_search.TabIndex = 0;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(644, 761);
            Controls.Add(listView1);
            Controls.Add(panel2);
            Controls.Add(panel1);
            ForeColor = Color.Black;
            MaximumSize = new Size(730, 850);
            MinimumSize = new Size(660, 800);
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "체크리스트";
            panel1.ResumeLayout(false);
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private ListView listView1;
        private Panel panel1;
        private Panel panel2;
        private TextBox textBox_search;
        private TextBox textBox_state;
        private Button search_button;
        private Label label1;
        private TextBox textBox_today;
        private Label label2;
        private ColumnHeader columnHeader1;
        private ColumnHeader columnHeader2;
        private ColumnHeader columnHeader3;
        private ColumnHeader columnHeader4;
        private ColumnHeader columnHeader5;
        private Label label3;
        private Button edit_dialog;
    }
}
