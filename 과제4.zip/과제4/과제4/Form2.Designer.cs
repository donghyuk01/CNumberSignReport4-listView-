﻿namespace 과제4
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            low = new RadioButton();
            middle = new RadioButton();
            high = new RadioButton();
            dateTimePicker1 = new DateTimePicker();
            add_button = new Button();
            textBox_t = new MaskedTextBox();
            del_button = new Button();
            edit_button = new Button();
            done_button = new Button();
            save_button = new Button();
            load_button = new Button();
            textBox1 = new TextBox();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.Controls.Add(low);
            panel1.Controls.Add(middle);
            panel1.Controls.Add(high);
            panel1.Controls.Add(dateTimePicker1);
            panel1.Controls.Add(add_button);
            panel1.Controls.Add(textBox_t);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(515, 145);
            panel1.TabIndex = 0;
            // 
            // low
            // 
            low.AutoSize = true;
            low.Location = new Point(222, 86);
            low.Name = "low";
            low.Size = new Size(49, 19);
            low.TabIndex = 3;
            low.TabStop = true;
            low.Text = "낮음";
            low.UseVisualStyleBackColor = true;
            // 
            // middle
            // 
            middle.AutoSize = true;
            middle.Location = new Point(121, 86);
            middle.Name = "middle";
            middle.Size = new Size(49, 19);
            middle.TabIndex = 3;
            middle.TabStop = true;
            middle.Text = "중간";
            middle.UseVisualStyleBackColor = true;
            // 
            // high
            // 
            high.AutoSize = true;
            high.Location = new Point(20, 86);
            high.Name = "high";
            high.Size = new Size(49, 19);
            high.TabIndex = 3;
            high.TabStop = true;
            high.Text = "높음";
            high.UseVisualStyleBackColor = true;
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(348, 41);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(160, 23);
            dateTimePicker1.TabIndex = 2;
            // 
            // add_button
            // 
            add_button.Location = new Point(348, 76);
            add_button.Name = "add_button";
            add_button.Size = new Size(160, 39);
            add_button.TabIndex = 1;
            add_button.Text = "추가";
            add_button.UseVisualStyleBackColor = true;
            add_button.Click += add_button_Click;
            // 
            // textBox_t
            // 
            textBox_t.Font = new Font("맑은 고딕", 12F, FontStyle.Regular, GraphicsUnit.Point, 129);
            textBox_t.Location = new Point(14, 35);
            textBox_t.Name = "textBox_t";
            textBox_t.Size = new Size(303, 29);
            textBox_t.TabIndex = 0;
            // 
            // del_button
            // 
            del_button.Location = new Point(20, 151);
            del_button.Name = "del_button";
            del_button.Size = new Size(90, 43);
            del_button.TabIndex = 1;
            del_button.Text = "삭제";
            del_button.UseVisualStyleBackColor = true;
            // 
            // edit_button
            // 
            edit_button.Location = new Point(121, 151);
            edit_button.Name = "edit_button";
            edit_button.Size = new Size(90, 43);
            edit_button.TabIndex = 1;
            edit_button.Text = "편집";
            edit_button.UseVisualStyleBackColor = true;
            // 
            // done_button
            // 
            done_button.Location = new Point(222, 151);
            done_button.Name = "done_button";
            done_button.Size = new Size(90, 43);
            done_button.TabIndex = 1;
            done_button.Text = "완료";
            done_button.UseVisualStyleBackColor = true;
            // 
            // save_button
            // 
            save_button.Location = new Point(359, 151);
            save_button.Name = "save_button";
            save_button.Size = new Size(60, 43);
            save_button.TabIndex = 1;
            save_button.Text = "저장";
            save_button.UseVisualStyleBackColor = true;
            // 
            // load_button
            // 
            load_button.Location = new Point(425, 151);
            load_button.Name = "load_button";
            load_button.Size = new Size(67, 43);
            load_button.TabIndex = 1;
            load_button.Text = "불러오기";
            load_button.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            textBox1.Font = new Font("맑은 고딕", 12F, FontStyle.Regular, GraphicsUnit.Point, 129);
            textBox1.Location = new Point(14, 224);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(325, 29);
            textBox1.TabIndex = 2;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(515, 307);
            Controls.Add(textBox1);
            Controls.Add(load_button);
            Controls.Add(save_button);
            Controls.Add(done_button);
            Controls.Add(edit_button);
            Controls.Add(del_button);
            Controls.Add(panel1);
            Name = "Form2";
            Text = "Form2";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private RadioButton middle;
        private RadioButton high;
        private DateTimePicker dateTimePicker1;
        private Button add_button;
        private MaskedTextBox textBox_t;
        private RadioButton low;
        private Button del_button;
        private Button edit_button;
        private Button done_button;
        private Button save_button;
        private Button load_button;
        private TextBox textBox1;
    }
}