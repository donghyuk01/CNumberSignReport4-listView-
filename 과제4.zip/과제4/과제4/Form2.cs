﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace 과제4
{
    
    public partial class Form2 : Form
    {
        Form1 f1;
        
        public Form2()
        {
            InitializeComponent();
        }
        public Form2(Form1 f)
        {
            InitializeComponent();
            f1 = f;
            dateTimePicker1.MinDate = DateTime.Today;
        }
        private void add_button_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox_t.Text))
            {
                MessageBox.Show("할 일을 입력해 주세요!", "알림");
                textBox_t.Focus();
                return;
            }
            if (dateTimePicker1.Value.Date < DateTime.Today)
            {
                MessageBox.Show("기한은 오늘보다 이전일 수 없습니다.", "날짜 오류");
                return;
            }

            if (!high.Checked && !middle.Checked && !low.Checked)
            {
                MessageBox.Show("우선순위를 선택해 주세요!", "알림");
                return;
            }
            string todo = textBox_t.Text;
            string dueDate = dateTimePicker1.Value.ToString("yyyy-MM-dd");
            string p = "";
            if (high.Checked)
            {
                p = "높음";
            }else if (middle.Checked)
            {
                p = "중간";
            }
            else if(low.Checked)
            {
                p = "낮음";
            }
            f1.AddToListView(todo, dueDate, p);
            clearItems();
        }
        private void clearItems()
        {
            textBox_t.Clear();
            dateTimePicker1.Value = DateTime.Now;
            high.Checked = false;
            middle.Checked = false;
            low.Checked = false;
            textBox_t.Focus();
        }
    }
}
